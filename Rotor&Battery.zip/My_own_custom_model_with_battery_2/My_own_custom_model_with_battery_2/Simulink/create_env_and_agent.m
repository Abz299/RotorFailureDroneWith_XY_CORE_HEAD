%% create_env_and_agent.m
% Create environment and RL agent for motor-failure recovery task.
% Model: withbatterymodel
% - Builds actor & critic networks
% - Creates rlSimulinkEnv and attaches ResetFcn
% - Creates DDPG agent (with correct NoiseOptions object)
% Agent action size changed to 6: [4 motors (0..1), 2 battery moves (-0.05..0.05)]


mdl = 'withbatterymodel';
agentBlockPath = [mdl '/RL Agent'];
Ts = 0.02;  % sample time (controller period)

%% --- Observation specification (unchanged: 17x1) ---
obsInfo = rlNumericSpec([17 1]);
obsInfo.Name = 'observation';
obsInfo.Description = ...
  'roll,pitch,yaw,wx,wy,wz,px,py,pz,vx,vy,vz,alt_error,MH1..MH4';

%% --- Action specification (6x1): 4 motor PWMs and 2 battery dx,dy ---
actInfo = rlNumericSpec([6 1]);
actInfo.Name = 'actions';
% Motor PWMs in [0,1], battery movements in [-0.05,0.05]
actInfo.LowerLimit = [0;0;0;0;-0.03;-0.03];
actInfo.UpperLimit = [1.2;1.2;1.2;1.2; 0.03; 0.03];

%% --- Create environment ---
open_system(mdl);
env = rlSimulinkEnv(mdl, agentBlockPath, obsInfo, actInfo);

% Attach reset function (make sure myResetFcn.m is on path)
env.ResetFcn = @(in) myResetFcn(in);

%% --- Actor network ---
% Input layer
statePath = featureInputLayer(17, 'Normalization','none','Name','state');

% Actor hidden layers and output
actorLayers = [
    fullyConnectedLayer(512,'Name','fc1_act')
    reluLayer('Name','relu1_act')
    fullyConnectedLayer(256,'Name','fc2_act')
    reluLayer('Name','relu2_act')
    fullyConnectedLayer(6,'Name','fcOut_act')    % changed output size to 6
    sigmoidLayer('Name','sigmoidOut_act')];      % outputs in [0,1]; rl toolbox will map to actInfo bounds

% Build layer graph for actor
actorLG = layerGraph();
actorLG = addLayers(actorLG, statePath);
actorLG = addLayers(actorLG, actorLayers);
actorLG = connectLayers(actorLG,'state','fc1_act');

actorOpts = rlRepresentationOptions( ...
    'LearnRate',1e-4, ...
    'GradientThreshold',1);

actor = rlDeterministicActorRepresentation( ...
    actorLG, obsInfo, actInfo, ...
    'Observation',{'state'}, actorOpts);

%% --- Critic network (Q-value) ---
% State path
statePathC = featureInputLayer(17,'Normalization','none','Name','stateC');
fc1C = fullyConnectedLayer(400,'Name','fc1C');
r1C  = reluLayer('Name','r1C');
fc2C = fullyConnectedLayer(300,'Name','fc2C');

% Action path (now 6)
actionPathC = featureInputLayer(6,'Normalization','none','Name','actionC');
fcA = fullyConnectedLayer(300,'Name','fcA');

% Merge + output
addL = additionLayer(2,'Name','add');
r2C = reluLayer('Name','r2C');
outC = fullyConnectedLayer(1,'Name','out');

% Build layer graph properly (add layers one-by-one)
lgraph = layerGraph();
lgraph = addLayers(lgraph,statePathC);
lgraph = addLayers(lgraph,fc1C);
lgraph = addLayers(lgraph,r1C);
lgraph = addLayers(lgraph,fc2C);
lgraph = addLayers(lgraph,actionPathC);
lgraph = addLayers(lgraph,fcA);
lgraph = addLayers(lgraph,addL);
lgraph = addLayers(lgraph,r2C);
lgraph = addLayers(lgraph,outC);

% Connect layers
lgraph = connectLayers(lgraph,'stateC','fc1C');
lgraph = connectLayers(lgraph,'fc1C','r1C');
lgraph = connectLayers(lgraph,'r1C','fc2C');

lgraph = connectLayers(lgraph,'actionC','fcA');

lgraph = connectLayers(lgraph,'fc2C','add/in1');
lgraph = connectLayers(lgraph,'fcA','add/in2');

lgraph = connectLayers(lgraph,'add','r2C');
lgraph = connectLayers(lgraph,'r2C','out');

criticOpts = rlRepresentationOptions('LearnRate',1e-3,'GradientThreshold',1);
critic = rlQValueRepresentation(lgraph, obsInfo, actInfo, ...
    'Observation',{'stateC'}, 'Action',{'actionC'}, criticOpts);

%% --- Agent options and Noise --- 
% Use GaussianActionNoise (works with DDPG)
noiseMean = zeros(actInfo.Dimension(1),1); % now 6x1
noiseVariance = 0.07;   % tuneable
noiseStd = sqrt(noiseVariance);
gaussNoise = rl.option.GaussianActionNoise('Mean',noiseMean,'StandardDeviation',noiseStd);

agentOpts = rlDDPGAgentOptions( ...
    SampleTime = Ts, ...
    TargetSmoothFactor = 1e-3, ...
    ExperienceBufferLength = 1e6, ...
    MiniBatchSize = 256, ...
    DiscountFactor = 0.99, ...
    CriticOptimizerOptions = rl.option.rlOptimizerOptions('LearnRate',1e-3), ...
    ActorOptimizerOptions  = rl.option.rlOptimizerOptions('LearnRate',1e-4), ...
    NoiseOptions = gaussNoise ...
    );

% Create DDPG agent
agent = rlDDPGAgent(actor, critic, agentOpts);

% --- (Optional) TD3 agent alternative (recommended for stability) ---
% To use TD3 instead, comment out DDPG creation above and use TD3 with two critics
% (make sure critic2 uses same layergraph as critic above).
%{ 
critic2 = rlQValueRepresentation(lgraph, obsInfo, actInfo, ...
    'Observation',{'stateC'}, 'Action',{'actionC'}, criticOpts);
td3Opts = rlTD3AgentOptions( ...
    SampleTime = Ts, ...
    ExperienceBufferLength = 1e6, ...
    MiniBatchSize = 256, ...
    DiscountFactor = 0.99, ...
    TargetPolicySmoothNoise = 0.2, ...
    TargetPolicySmoothNoiseClip = 0.5);
agent = rlTD3Agent(actor, critic, critic2, td3Opts);
%}

%% --- Put env and agent in base workspace ---
assignin('base','env',env);
assignin('base','agent',agent);

fprintf('\nEnvironment and agent created successfully (6-D action space: 4 motors + 2 battery moves).\n');
fprintf('Run train(agent, env, trainOpts) or run your train_agent.m script to start training.\n\n');
