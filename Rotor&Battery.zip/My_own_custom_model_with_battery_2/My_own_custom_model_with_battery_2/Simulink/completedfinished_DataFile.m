% Simscape(TM) Multibody(TM) version: 24.1

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(20).translation = [0.0 0.0 0.0];
smiData.RigidTransform(20).angle = 0.0;
smiData.RigidTransform(20).axis = [0.0 0.0 0.0];
smiData.RigidTransform(20).ID = "";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0 0 0];  % cm
smiData.RigidTransform(1).angle = 0;  % rad
smiData.RigidTransform(1).axis = [0 0 0];
smiData.RigidTransform(1).ID = "B[framefinished1-2:-:]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [0 0 0];  % cm
smiData.RigidTransform(2).angle = 0;  % rad
smiData.RigidTransform(2).axis = [0 0 0];
smiData.RigidTransform(2).ID = "F[framefinished1-2:-:]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [-8.3266726846886741e-13 0 -0.94999999999999951];  % cm
smiData.RigidTransform(3).angle = 8.7527193656492581e-13;  % rad
smiData.RigidTransform(3).axis = [-0.00011464600491012687 0.99999999342814672 -5.0173215038828354e-17];
smiData.RigidTransform(3).ID = "B[finishedrotorpropnonflipped-2:-:framefinished1-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [13.567551465985682 -12.660101056458165 3.1503077585179398];  % cm
smiData.RigidTransform(4).angle = 2.236067977499815e-15;  % rad
smiData.RigidTransform(4).axis = [0.44721359549995315 0.8944271909999183 4.472135954999595e-16];
smiData.RigidTransform(4).ID = "F[finishedrotorpropnonflipped-2:-:framefinished1-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [-8.2989171090730451e-13 0 -0.95000000000000018];  % cm
smiData.RigidTransform(5).angle = 8.7527193656492581e-13;  % rad
smiData.RigidTransform(5).axis = [-0.00011464600491012978 0.99999999342814672 -5.0173215038829636e-17];
smiData.RigidTransform(5).ID = "B[finishedrotorpropnonflipped-3:-:framefinished1-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-13.562903786721542 12.664042899330564 3.1766887962172623];  % cm
smiData.RigidTransform(6).angle = 1.4142135623731404e-15;  % rad
smiData.RigidTransform(6).axis = [-0.70710678118653225 0.70710678118656278 -3.5355339059328511e-16];
smiData.RigidTransform(6).ID = "F[finishedrotorpropnonflipped-3:-:framefinished1-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [-8.2989171090730451e-13 0 -0.95000000000000018];  % cm
smiData.RigidTransform(7).angle = 8.752719365649256e-13;  % rad
smiData.RigidTransform(7).axis = [-0.00011464600491009308 0.99999999342814672 -5.0173215038813563e-17];
smiData.RigidTransform(7).ID = "B[finishedrotorpropflipped-1:-:framefinished1-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [13.565032574539043 12.662511281177553 3.149784083673052];  % cm
smiData.RigidTransform(8).angle = 1.0003754947596959e-15;  % rad
smiData.RigidTransform(8).axis = [-0.70141368798588022 0.71275440251607436 -2.5006170866514534e-16];
smiData.RigidTransform(8).ID = "F[finishedrotorpropflipped-1:-:framefinished1-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [-8.3266726846886741e-13 0 -0.95000000000000018];  % cm
smiData.RigidTransform(9).angle = 8.752719365649255e-13;  % rad
smiData.RigidTransform(9).axis = [-0.00011464600491049282 0.99999999342814672 -5.0173215038988493e-17];
smiData.RigidTransform(9).ID = "B[finishedrotorpropflipped-3:-:framefinished1-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [-13.560383664039104 -12.666451836644322 3.1503077585179629];  % cm
smiData.RigidTransform(10).angle = 6.9290226746226796e-16;  % rad
smiData.RigidTransform(10).axis = [0.69290226746205297 0.72103151647202324 1.7308850133030911e-16];
smiData.RigidTransform(10).ID = "F[finishedrotorpropflipped-3:-:framefinished1-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [-7.250820977644687 6.0051989890372708 -3.1500000000000252];  % cm
smiData.RigidTransform(11).angle = 3.1415926535897922;  % rad
smiData.RigidTransform(11).axis = [1 -2.4997565715216048e-31 -4.9999999526009823e-16];
smiData.RigidTransform(11).ID = "B[framefinished1-2:-:battery-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-7.2500000000000044 -5.9999999999999964 3.1991911592197113e-15];  % cm
smiData.RigidTransform(12).angle = 9.7366653225843672e-05;  % rad
smiData.RigidTransform(12).axis = [-1.1968293955292571e-17 2.4583969057243472e-13 -1];
smiData.RigidTransform(12).ID = "F[framefinished1-2:-:battery-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [1.2406742300186124e-12 0 1.4200000000000004];  % cm
smiData.RigidTransform(13).angle = 0.68091228781842439;  % rad
smiData.RigidTransform(13).axis = [4.3761864153031867e-13 1.2353732112725216e-12 1];
smiData.RigidTransform(13).ID = "AssemblyGround[finishedrotorpropnonflipped-3:nonflippedwingfinished.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [0 0 0];  % cm
smiData.RigidTransform(14).angle = 0;  % rad
smiData.RigidTransform(14).axis = [0 0 0];
smiData.RigidTransform(14).ID = "AssemblyGround[finishedrotorpropnonflipped-3:rotorfinished.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [1.2434497875801753e-12 0 1.4200000000000004];  % cm
smiData.RigidTransform(15).angle = 0.68091228781842472;  % rad
smiData.RigidTransform(15).axis = [4.3761864153031851e-13 1.235373211272521e-12 1];
smiData.RigidTransform(15).ID = "AssemblyGround[finishedrotorpropnonflipped-2:nonflippedwingfinished.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [0 0 0];  % cm
smiData.RigidTransform(16).angle = 0;  % rad
smiData.RigidTransform(16).axis = [0 0 0];
smiData.RigidTransform(16).ID = "AssemblyGround[finishedrotorpropnonflipped-2:rotorfinished.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [1.2490009027033011e-12 0 1.4200000000000004];  % cm
smiData.RigidTransform(17).angle = 0.10208823569909316;  % rad
smiData.RigidTransform(17).axis = [-4.3756363503261261e-13 8.5663040317681572e-12 -1];
smiData.RigidTransform(17).ID = "AssemblyGround[finishedrotorpropflipped-1:flippedwingfinished.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [0 0 0];  % cm
smiData.RigidTransform(18).angle = 0;  % rad
smiData.RigidTransform(18).axis = [0 0 0];
smiData.RigidTransform(18).ID = "AssemblyGround[finishedrotorpropflipped-1:rotorfinished.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [1.2434497875801753e-12 0 1.4200000000000004];  % cm
smiData.RigidTransform(19).angle = 0.10208823569909332;  % rad
smiData.RigidTransform(19).axis = [-4.3756363503261155e-13 8.5663040317681427e-12 -1];
smiData.RigidTransform(19).ID = "AssemblyGround[finishedrotorpropflipped-3:flippedwingfinished.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [0 0 0];  % cm
smiData.RigidTransform(20).angle = 0;  % rad
smiData.RigidTransform(20).axis = [0 0 0];
smiData.RigidTransform(20).ID = "AssemblyGround[finishedrotorpropflipped-3:rotorfinished.step-1]";


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(5).mass = 0.0;
smiData.Solid(5).CoM = [0.0 0.0 0.0];
smiData.Solid(5).MoI = [0.0 0.0 0.0];
smiData.Solid(5).PoI = [0.0 0.0 0.0];
smiData.Solid(5).color = [0.0 0.0 0.0];
smiData.Solid(5).opacity = 0.0;
smiData.Solid(5).ID = "";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.20000000000000001;  % kg
smiData.Solid(1).CoM = [0 0 1.2468704661574748];  % cm
smiData.Solid(1).MoI = [1.7651165023420292 0.30675468477599865 1.8645108247238176];  % kg*cm^2
smiData.Solid(1).PoI = [0 0 0];  % kg*cm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = "battery*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.00598682157874418;  % kg
smiData.Solid(2).CoM = [0 0 -0.22151725543867695];  % cm
smiData.Solid(2).MoI = [0.1253685178716088 0.0015357263737931499 0.12637380963594641];  % kg*cm^2
smiData.Solid(2).PoI = [0 0 0.00014180616974316206];  % kg*cm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = "nonflippedwingfinished.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.0052795708346069807;  % kg
smiData.Solid(3).CoM = [1.3366135118319792e-07 5.6957335241986099e-08 -0.49517080774472577];  % cm
smiData.Solid(3).MoI = [0.0035377752050707824 0.0035377732170493639 0.0050858007684934708];  % kg*cm^2
smiData.Solid(3).PoI = [-1.0867747701523821e-10 -2.8299890141121584e-10 7.4889176015515486e-10];  % kg*cm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = "rotorfinished.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.0059869591163983511;  % kg
smiData.Solid(4).CoM = [-9.3833838640161063e-12 3.4108765593942798e-12 -0.22152335689124397];  % cm
smiData.Solid(4).MoI = [0.0035184355864650032 0.12336885551522765 0.12635683749732254];  % kg*cm^2
smiData.Solid(4).PoI = [0 0 -0.015542872877328208];  % kg*cm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = "flippedwingfinished.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.53492452726989004;  % kg
smiData.Solid(5).CoM = [0.00026466995313515276 0.00025362371160425932 0.35203971575152188];  % cm
smiData.Solid(5).MoI = [22.874579460337745 29.880595986848071 47.641869465224403];  % kg*cm^2
smiData.Solid(5).PoI = [-0.015878890699451503 0.020246247084505509 -0.00064487134329108825];  % kg*cm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = "framefinished1*:*Default";


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(4).Rz.Pos = 0.0;
smiData.RevoluteJoint(4).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = -2.3906803948482862;  % deg
smiData.RevoluteJoint(1).ID = "[finishedrotorpropnonflipped-2:-:framefinished1-2]";

smiData.RevoluteJoint(2).Rz.Pos = -2.3436460471179057;  % deg
smiData.RevoluteJoint(2).ID = "[finishedrotorpropnonflipped-3:-:framefinished1-2]";

smiData.RevoluteJoint(3).Rz.Pos = -47.165679778357102;  % deg
smiData.RevoluteJoint(3).ID = "[finishedrotorpropflipped-1:-:framefinished1-2]";

smiData.RevoluteJoint(4).Rz.Pos = 132.66024687911084;  % deg
smiData.RevoluteJoint(4).ID = "[finishedrotorpropflipped-3:-:framefinished1-2]";

