function in = myResetFcn(in)
% Resets initial attitude/altitude for each episode (PID takeoff phase)
% Keeps original behavior, and adds initial battery offsets variables.

in = setVariable(in,'MotorHealthy',[1 1 1 1],'Workspace','base'); % all on
in = setVariable(in,'TrainMode',0,'Workspace','base');             % start with PID

% Small attitude noise only
in = setVariable(in,'initRoll',  deg2rad((rand-0.5)*2), 'Workspace','base');
in = setVariable(in,'initPitch', deg2rad((rand-0.5)*2), 'Workspace','base');
in = setVariable(in,'initYaw',   deg2rad((rand-0.5)*4), 'Workspace','base');
in = setVariable(in,'initWx',    0, 'Workspace','base');
in = setVariable(in,'initWy',    0, 'Workspace','base');
in = setVariable(in,'initWz',    0, 'Workspace','base');

% Add small random initial battery position (within allowed bounds)
% These variables can be used by the Simulink model to set battery initial XY
init_batt_x = (rand-0.5)*0.02; % ±0.01 m initial small offset
init_batt_y = (rand-0.5)*0.02;
in = setVariable(in,'initBatteryX', init_batt_x, 'Workspace','base');
in = setVariable(in,'initBatteryY', init_batt_y, 'Workspace','base');

end
