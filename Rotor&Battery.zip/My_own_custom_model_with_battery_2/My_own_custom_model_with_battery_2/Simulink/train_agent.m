    %% train_agent.m
    % Run this after create_env_and_agent.m (so env & agent exist in workspace)
    mdl = 'withbatterymodel';
    open_system(mdl);
    
    disp('=== Starting RL Training: PID takeoff → RL takeover → Motor 2 fail ===');
    
    %% Environment warm-up
    % Make sure simulation variables exist in base workspace
    % assignin('base','TrainMode',0);                % PID control initially
    % assignin('base','MotorHealthy',[1 1 1 1]);     % all motors on
    
    %% Training options
    saveDir = fullfile(pwd,'savedAgents_recovery'); % folder for periodic saves
    if ~exist(saveDir,'dir')
        mkdir(saveDir);
    end
    
    trainOpts = rlTrainingOptions( ...
        MaxEpisodes               = 2000, ...      % total episodes
        MaxStepsPerEpisode        = 15, ...      % each ~20 s (Ts=0.02)
        Verbose                   = true, ...
        Plots                     = "training-progress", ...
        StopTrainingCriteria      = "EpisodeCount", ...
        StopTrainingValue         = 2000, ...       % leave as before (tune if needed)
        ScoreAveragingWindowLength= 100, ...
        SaveAgentCriteria         = "EpisodeFrequency", ...
        SaveAgentValue            = 50, ...        % save every 50 episodes
        SaveAgentDirectory        = saveDir, ...
        SimulationStorageType     = "file", ...
        UseParallel               = false ...
        );
    
    %% Start training
    fprintf('\n--- Training started (%s) ---\n', datestr(now));
    trainingStats = train(agent, env, trainOpts);
    
    %% Save final agent & results
    finalName = fullfile(pwd,'trainedAgent_motor2_final.mat');
    save(finalName,'agent','trainingStats','-v7.3');
    
    fprintf('\n=== Training complete ===\n');
    fprintf('Final agent saved to: %s\n', finalName);
    fprintf('Periodic agents saved to: %s\n', saveDir);
