%% resume_training_agent.m
% Resume RL training from previously saved agent & stats
% It loads previous agent and training results, continues training,
% and merges new stats safely (without modifying read-only properties).

clear; clc; close all;


run('completedfinished_DataFile.m')
load('SimulationInfo2050.mat')

mdl = 'withbatterymodel';
open_system(mdl);


fprintf('=== Resuming RL Training: continuing from previous saved agent ===\n');

%% --- Load previous agent & stats ---
prevAgentFile = fullfile(pwd,'Agent2050.mat');  % previous save
if exist(prevAgentFile, 'file')
    prevData = load(prevAgentFile, 'agent', 'trainingStats');
    agent = prevData.agent;
    oldStats = prevData.trainingStats;
    fprintf('Loaded previous agent and training stats successfully.\n');
else
    error('Previous agent file not found: %s', prevAgentFile);
end

%% --- Load environment (if not already in workspace) ---
if ~exist('env', 'var')
    create_env_and_agent;   % this script defines 'env'
    fprintf('Environment recreated.\n');
end

%% --- Training options for continuation ---
saveDir = fullfile(pwd, 'savedAgents_resume');
if ~exist(saveDir, 'dir')
    mkdir(saveDir);
end

trainOpts = rlTrainingOptions( ...
    MaxEpisodes               = 2000, ...              % continue for 50 more
    MaxStepsPerEpisode        = 2000, ...
    Verbose                   = true, ...
    Plots                     = "training-progress", ...
    StopTrainingCriteria      = "EpisodeCount", ...
    StopTrainingValue         = 2000, ...
    ScoreAveragingWindowLength= 100, ...
    SaveAgentCriteria         = "EpisodeFrequency", ...
    SaveAgentValue            = 50, ...
    SaveAgentDirectory        = saveDir, ...
    SimulationStorageType     = "file", ...
    UseParallel               = false ...
    );

fprintf('\n--- Continuing training (%s) ---\n', datestr(now));
trainingStats_resume = train(agent, env, trainOpts);

%% --- Merge old and new stats safely ---
fprintf('\nMerging previous and resumed training stats...\n');
fields = fieldnames(trainingStats_resume);
mergedStats = struct();

for i = 1:numel(fields)
    f = fields{i};
    % Avoid read-only properties like EpisodeIndex
    try
        mergedStats.(f) = [oldStats.(f); trainingStats_resume.(f)];
    catch
        % If property is read-only, skip it
        mergedStats.(f) = oldStats.(f);
    end
end

%% --- Save combined results ---
finalName = fullfile(pwd, 'resumed_saved_agent_1.mat');
save(finalName, 'agent', 'mergedStats', '-v7.3');

fprintf('\n=== Training resumed and completed successfully ===\n');
fprintf('Final resumed agent saved to: %s\n', finalName);
fprintf('Intermediate agents saved to: %s\n', saveDir);
