%% ==================== resume_training_motor2.m ====================
%% --- Load environment data if any ---
run('completedfinished_DataFile.m');  % your existing data file

%% --- Open Simulink model ---
mdl = 'completedfinished2024';
open_system(mdl);

%% --- Load previously trained agent & stats ---
agentFile = 'C:\Users\abuba\Desktop\My_own_custom_RL_2_with_0_pwm\My_own_custom_RL_2_with_0_pwm\trainedAgent_motor2_final_resumed.mat';
load(agentFile, 'agent','trainingStats');  % loads agent & previous training stats

%% --- Create RL environment using saved agent specs ---
obsInfo = agent.ObservationInfo;
actInfo = agent.ActionInfo;

% Use exact RL Agent block path in your model
env = rlSimulinkEnv(mdl, 'completedfinished2024/RL Agent', obsInfo, actInfo);

%% --- Training options ---
saveDir = fullfile(pwd,'savedAgents_recovery'); 
if ~exist(saveDir,'dir')
    mkdir(saveDir);
end

trainOpts = rlTrainingOptions( ...
    MaxEpisodes               = 3000, ...        % total episodes
    MaxStepsPerEpisode        = 1000, ...        % adjust if needed
    Verbose                   = true, ...
    Plots                     = "training-progress", ...
    StopTrainingCriteria      = "EpisodeCount", ...
    StopTrainingValue         = 500, ...         % continue improving beyond 300
    ScoreAveragingWindowLength= 100, ...
    SaveAgentCriteria         = "EpisodeFrequency", ...
    SaveAgentValue            = 50, ...
    SaveAgentDirectory        = saveDir, ...
    SimulationStorageType     = "file", ...
    UseParallel               = false ...
    );

%% --- Resume training ---
fprintf('\n--- Resuming RL Training ---\n');
trainingStats = train(agent, env, trainOpts);

%% --- Save final agent & results ---
finalName = fullfile(pwd,'trainedAgent_motor2_final_resumed.mat');
save(finalName,'agent','trainingStats','-v7.3');

fprintf('\n=== Training complete ===\n');
fprintf('Final agent saved to: %s\n', finalName);
fprintf('Periodic agents saved to: %s\n', saveDir);
