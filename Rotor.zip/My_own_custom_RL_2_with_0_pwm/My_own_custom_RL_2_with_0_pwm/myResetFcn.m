function in = myResetFcn(in)
% Resets initial attitude/altitude for each episode (PID takeoff phase)
in = setVariable(in,'MotorHealthy',[1 1 1 1],'Workspace','base'); % all on
in = setVariable(in,'TrainMode',0,'Workspace','base');             % start with PID

% Small attitude noise only
in = setVariable(in,'initRoll',  deg2rad((rand-0.5)*2), 'Workspace','base');
in = setVariable(in,'initPitch', deg2rad((rand-0.5)*2), 'Workspace','base');
in = setVariable(in,'initYaw',   deg2rad((rand-0.5)*4), 'Workspace','base');
in = setVariable(in,'initWx',    0, 'Workspace','base');
in = setVariable(in,'initWy',    0, 'Workspace','base');
in = setVariable(in,'initWz',    0, 'Workspace','base');
end
